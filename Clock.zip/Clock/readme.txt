
 Carolyn's Clock
 ======================
 Published: 2019-MAY-29
 
 The clock application was written using Visual Basic .NET as a stand alone
 desktop application. This means that it requires that the proper version of
 the Microsoft .NET Framework be installed. This version of the app requires
 the .NET Framework version 4.6.2 be installed. You can download this for
 free from the https://dotnet.microsoft.com web site.
 
 There are several products and versions here. You want the .NET Framework
 (not the .NET Core). You want version 4.6.2 for Windows.
 
 The application is compiled for any CPU and for 32-bit operation.
 
 The application is installed on a per-user basis. This means that if your
 computer is set up for multiple user accounts in Windows, only the account
 under which the application was installed will have access to it.
 
 It's strongly recommended that you read the documentation before using the
 application. Especially if you're not familiar with Windows concepts like
 the Task Bar and Notification Area.
 
 IMPORTANT  The documentation requires that a modern web browser is
            installed on your computer and that it is set as the default
            browser (in effect, the one that automatically opens when you
            click on a saved web page or hyperlink). Furthermore, the web
            browser must have JavaScript enabled. Modern for our purposes
            implies support for HTML5, CSS3 and ECMAScript6. If you aren't
            certain, you can try googling these terms and looking for sites
            that offer web browser compatibility charts or testing. This
            really shouldn't be an issue for most people. Windows 10 comes
            with the Edge browser, which is suitable. Chrome and FireFox
            are excellent choices as well. You may want to see if your
            browser has an upgrade available and that it is set up to
            allow JavaScript to run.
 
 If you run into any trouble or have any suggestions, please feel free to
 send us feedback at:
 
  nyteowl.2019@gmail.com
 
 You're also invited to visit our web sites at:
 
  http://davewellsted.ddns.net
 
 and
 
  https://nyteowl-computer-software.business.site
 
 Happy Computing!
 
 